const axios = require('axios')

const BOT_TOKEN = '7519327653:AAGs84-CVVDfXmv5w-pXJL5tK429f_fCk0g'

const CHAT_ID = '-4742652446'

async function handelbot (message) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=${message}`
  try {
    const response = await axios.post(url)
    console.log('Message sent:', response.data)
  } catch (error) {
    console.error(
      'Error sending message:',
      error.response ? error.response.data : error.message
    )
  }
}

module.exports = { handelbot }
